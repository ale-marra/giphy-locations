#Problem

write a Python server that takes JSON input (some string being typed on the front end) and than calls GoogleMaps getting a list of location with whatever the input was (i.e. sometimes Washington and back comes a number of places with Washington in it) and Gyphi (https://giphy.com/) getting a suggested giphies for those places


## Considerations

In order to minimize the number of requests, this program saves all the pages it visits.


## Compatability

This program has been written with Python 3.6.3


## Install

The requirements are Flask and giphypop and requests and can be installed with pip install -r requirements.txt


## Author

**Alessandro Marra** - (https://github.com/Ale-Marra)
# giphy-query
# giphy-query
